{{/*
Base name
*/}}
{{- define "simplicite.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name
*/}}
{{- define "simplicite.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "simplicite.labels" -}}
app.kubernetes.io/name: {{ include "simplicite.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}

{{/*
Database fullname (used as DB_HOST and Service/Deployment name)
*/}}
{{- define "simplicite.database.fullname" -}}
{{- printf "%s-database" (include "simplicite.fullname" .) -}}
{{- end -}}

{{/*
Simplicite app fullname
*/}}
{{- define "simplicite.app.fullname" -}}
{{- printf "%s-simplicite" (include "simplicite.fullname" .) -}}
{{- end -}}
